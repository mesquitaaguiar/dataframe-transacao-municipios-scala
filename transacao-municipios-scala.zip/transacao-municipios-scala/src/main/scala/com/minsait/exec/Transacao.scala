package com.minsait.exec

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object Transacao {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder()
      .appName("Exec Transacao")
      .master("local[*]")
      .getOrCreate()

    val df = spark.read.option("delimiter", ";").csv("file:////apps//*.txt").toDF("id_transacao","nm_municipio","nm_estado","dt_atualizacao","ordem_transacao").cache()

    df.createOrReplaceTempView("transacao")

    println(spark.sql("SELECT * FROM transacao order by nm_municipio").show())

    spark.stop()
  }
}
